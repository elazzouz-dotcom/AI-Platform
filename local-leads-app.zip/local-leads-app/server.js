const http = require('node:http');
const fs = require('node:fs/promises');
const path = require('node:path');
const crypto = require('node:crypto');

const HOST = '127.0.0.1';
const PORT = Number(process.env.PORT || 3000);
const ROOT = __dirname;
const DATA_FILE = path.join(ROOT, 'data', 'leads.json');
const PUBLIC_DIR = path.join(ROOT, 'public');

const headers = {
  'Access-Control-Allow-Origin': `http://${HOST}:${PORT}`,
  'Access-Control-Allow-Methods': 'GET, POST, OPTIONS',
  'Access-Control-Allow-Headers': 'Content-Type',
};

async function readLeads() {
  try { return JSON.parse(await fs.readFile(DATA_FILE, 'utf8')); }
  catch { return []; }
}

async function writeLeads(leads) {
  await fs.writeFile(DATA_FILE, JSON.stringify(leads, null, 2) + '\n', 'utf8');
}

function send(res, status, body, contentType = 'application/json; charset=utf-8') {
  res.writeHead(status, { ...headers, 'Content-Type': contentType });
  res.end(typeof body === 'string' ? body : JSON.stringify(body));
}

function clean(value, max = 2000) {
  return typeof value === 'string' ? value.trim().slice(0, max) : '';
}

function validEmail(value) { return !value || /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(value); }
function validPhone(value) { return !value || /^[+0-9\s()\-]{8,}$/.test(value); }

async function readBody(req) {
  let raw = '';
  for await (const chunk of req) {
    raw += chunk;
    if (raw.length > 100_000) throw new Error('payload_too_large');
  }
  return JSON.parse(raw || '{}');
}

async function serveStatic(req, res) {
  const requested = req.url === '/' ? '/index.html' : req.url.split('?')[0];
  const file = path.resolve(PUBLIC_DIR, '.' + requested);
  if (!file.startsWith(PUBLIC_DIR)) return send(res, 403, { error: 'forbidden' });
  try {
    const content = await fs.readFile(file);
    const type = file.endsWith('.html') ? 'text/html; charset=utf-8' : 'text/plain; charset=utf-8';
    send(res, 200, content, type);
  } catch { send(res, 404, 'Not found', 'text/plain; charset=utf-8'); }
}

const server = http.createServer(async (req, res) => {
  try {
    if (req.method === 'OPTIONS') return send(res, 204, '');

    if (req.method === 'POST' && req.url === '/api/leads') {
      const input = await readBody(req);
      const lead = {
        id: crypto.randomUUID(),
        createdAt: new Date().toISOString(),
        name: clean(input.name, 120),
        phone: clean(input.phone, 40),
        email: clean(input.email, 160),
        projectType: clean(input.projectType, 80),
        message: clean(input.message, 4000),
        status: 'جديد'
      };

      if (input.website) return send(res, 201, { ok: true });
      if (!lead.name || !lead.message) return send(res, 400, { ok: false, error: 'الاسم والرسالة مطلوبان' });
      if (!validPhone(lead.phone)) return send(res, 400, { ok: false, error: 'رقم الهاتف غير صحيح' });
      if (!validEmail(lead.email)) return send(res, 400, { ok: false, error: 'البريد الإلكتروني غير صحيح' });

      const leads = await readLeads();
      leads.unshift(lead);
      await writeLeads(leads);
      return send(res, 201, { ok: true, id: lead.id });
    }

    if (req.method === 'GET' && req.url === '/api/leads') {
      return send(res, 200, { ok: true, leads: await readLeads() });
    }

    if (req.method === 'GET') return serveStatic(req, res);
    return send(res, 405, { error: 'method_not_allowed' });
  } catch (error) {
    const status = error.message === 'payload_too_large' ? 413 : 400;
    send(res, status, { ok: false, error: 'تعذّر معالجة الطلب' });
  }
});

server.listen(PORT, HOST, () => {
  console.log(`\n✅ التطبيق يعمل محلياً على: http://${HOST}:${PORT}`);
  console.log(`📁 الطلبات تُحفظ في: ${DATA_FILE}`);
  console.log('⏹ أوقفه عبر Ctrl+C\n');
});
